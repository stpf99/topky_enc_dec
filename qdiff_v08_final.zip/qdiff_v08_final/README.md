# QDIFF Codec v0.8 (final)

## Pliki
- `qdiff_codec_v0.8.py` — główny kodek (magic QDF8)
- `toptopuw_vlc.py` — moduł VLC run-level (wymagany obok kodeka)
- `test_mref.qdiff` — przykładowy strumień (12 klatek)
- `test_mref_dec.mp4` — zdekodowany wynik
- `video-in.mp4` — materiał testowy (jeśli dołączony)

## Wymagania
```
pip install numpy scipy zstandard av
# opcjonalnie: numba, imageio, imageio-ffmpeg
```

## Użycie
```bash
# encode
python qdiff_codec_v0.8.py -i input.mp4 -o out.qdiff -a -f

# decode
python qdiff_codec_v0.8.py -i out.qdiff -o decoded.mp4 -d
```

## Co jest w v0.8
- VLC run-level + wybór min (sparse/RLE/VLC)
- Family RLE, kompaktowe delta-MV
- Intra prediction + block-based I-frame
- Adaptive TX 16x16 vs 4x8x8
- Deblock + SAO, perceptual auto Q
- Hierarchical ME, sub-pixel, **multi-ref (2 refs)**
